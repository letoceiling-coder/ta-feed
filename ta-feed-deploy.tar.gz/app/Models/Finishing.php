<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Finishing extends Model
{
    protected $fillable = ['name'];

    public function apartments(): HasMany
    {
        return $this->hasMany(Apartment::class);
    }
}
