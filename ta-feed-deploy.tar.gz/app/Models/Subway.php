<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Subway extends Model
{
    protected $fillable = ['name'];

    public function blocks(): BelongsToMany
    {
        return $this->belongsToMany(Block::class)
            ->withPivot('distance_time', 'distance_type');
    }
}
