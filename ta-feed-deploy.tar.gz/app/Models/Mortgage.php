<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Mortgage extends Model
{
    protected $fillable = ['name'];

    public function buildings(): BelongsToMany
    {
        return $this->belongsToMany(Building::class);
    }
}
