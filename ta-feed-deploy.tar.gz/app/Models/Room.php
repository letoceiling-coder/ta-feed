<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Room extends Model
{
    protected $fillable = ['name', 'value'];

    public function apartments(): HasMany
    {
        return $this->hasMany(Apartment::class);
    }
}
